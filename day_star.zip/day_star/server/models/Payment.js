const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Child = require('./Child');
const User = require('./User');

const Payment = sequelize.define('Payment', {
  payment_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  child_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'children',
      key: 'child_id'
    }
  },
  parent_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'user_id'
    }
  },
  amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  payment_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  payment_method: {
    type: DataTypes.ENUM('Cash', 'Credit Card', 'Bank Transfer', 'Mobile Money'),
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('Pending', 'Completed', 'Failed', 'Refunded'),
    allowNull: false,
    defaultValue: 'Pending'
  },
  receipt_number: {
    type: DataTypes.STRING,
    allowNull: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'payments'
});

// Define associations
Payment.belongsTo(Child, {
  foreignKey: 'child_id',
  as: 'child'
});

Payment.belongsTo(User, {
  foreignKey: 'parent_id',
  as: 'parent'
});

module.exports = Payment; 