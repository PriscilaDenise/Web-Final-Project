const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Notification = sequelize.define('Notification', {
  notification_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'user_id'
    }
  },
  notification_type: {
    type: DataTypes.ENUM('Child_Status', 'Payment_Reminder', 'Overdue_Payment', 'Budget_Alert', 'Incident_Report'),
    allowNull: false
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('Sent', 'Read'),
    allowNull: false,
    defaultValue: 'Sent'
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'Notifications'
});

Notification.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Notification; 