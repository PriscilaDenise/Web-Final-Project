const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Child = require('./Child');
const Babysitter = require('./Babysitter');

const ChildAttendance = sequelize.define('ChildAttendance', {
  attendance_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  child_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Child,
      key: 'child_id'
    }
  },
  babysitter_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Babysitter,
      key: 'babysitter_id'
    }
  },
  check_in_time: {
    type: DataTypes.DATE,
    allowNull: true
  },
  check_out_time: {
    type: DataTypes.DATE,
    allowNull: true
  },
  session_date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  session_type: {
    type: DataTypes.ENUM('Half-Day', 'Full-Day'),
    allowNull: false
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'Child_Attendance'
});

ChildAttendance.belongsTo(Child, { foreignKey: 'child_id' });
ChildAttendance.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });

module.exports = ChildAttendance; 