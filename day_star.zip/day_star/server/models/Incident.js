const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Child = require('./Child');
const Babysitter = require('./Babysitter');
const User = require('./User');

const Incident = sequelize.define('Incident', {
  incident_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  child_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'children',
      key: 'child_id'
    }
  },
  babysitter_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'babysitters',
      key: 'babysitter_id'
    }
  },
  manager_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'user_id'
    }
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  time: {
    type: DataTypes.TIME,
    allowNull: false
  },
  incident_type: {
    type: DataTypes.ENUM('Injury', 'Illness', 'Behavioral', 'Other'),
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  action_taken: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  follow_up: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('Open', 'In Progress', 'Resolved', 'Closed'),
    allowNull: false,
    defaultValue: 'Open'
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'incidents'
});

// Define associations
Incident.belongsTo(Child, {
  foreignKey: 'child_id',
  as: 'child'
});

Incident.belongsTo(Babysitter, {
  foreignKey: 'babysitter_id',
  as: 'babysitter'
});

Incident.belongsTo(User, {
  foreignKey: 'manager_id',
  as: 'manager'
});

module.exports = Incident; 