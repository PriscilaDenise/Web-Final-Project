const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Babysitter = require('./Babysitter');

const Schedule = sequelize.define('Schedule', {
  schedule_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  babysitter_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Babysitter,
      key: 'babysitter_id'
    }
  },
  schedule_date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  start_time: {
    type: DataTypes.TIME,
    allowNull: false
  },
  end_time: {
    type: DataTypes.TIME,
    allowNull: false
  },
  session_type: {
    type: DataTypes.ENUM('Half-Day', 'Full-Day'),
    allowNull: false
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'Babysitter_Schedules',
  indexes: [
    {
      unique: true,
      fields: ['babysitter_id', 'schedule_date', 'start_time']
    }
  ]
});

Schedule.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });

module.exports = Schedule; 