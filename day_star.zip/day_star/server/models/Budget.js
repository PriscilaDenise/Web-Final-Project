const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Budget = sequelize.define('Budget', {
  budget_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  category: {
    type: DataTypes.ENUM('Babysitter_Salaries', 'Toys_Procurement', 'Maintenance', 'Utilities', 'Other'),
    allowNull: false
  },
  budget_amount: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  period_start: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  period_end: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  type: {
    type: DataTypes.ENUM('income', 'expense'),
    allowNull: false,
    validate: {
      isIn: [['income', 'expense']]
    }
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'user_id'
    }
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'Budgets',
  indexes: [
    {
      unique: true,
      fields: ['category', 'period_start']
    }
  ]
});

Budget.belongsTo(User, { foreignKey: 'created_by', as: 'creator' });

module.exports = Budget; 