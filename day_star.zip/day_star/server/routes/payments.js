const express = require('express');
const router = express.Router();
const { Payment, Child, User } = require('../models');
const { authenticateToken, isManager } = require('../middleware/auth');

// Create new payment
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      child_id,
      amount,
      payment_date,
      payment_method,
      description,
      receipt_number
    } = req.body;

    // If user is parent, ensure they can only create payments for their children
    if (req.user.role === 'Parent') {
      const child = await Child.findByPk(child_id);
      if (!child || child.user_id !== req.user.id) {
        return res.status(403).json({ message: 'Parents can only create payments for their children' });
      }
    }

    const payment = await Payment.create({
      child_id,
      amount,
      payment_date,
      payment_method,
      description,
      receipt_number,
      status: 'pending'
    });

    res.status(201).json({
      message: 'Payment created successfully',
      payment
    });
  } catch (error) {
    console.error('Error creating payment:', error);
    res.status(500).json({ message: 'Error creating payment' });
  }
});

// Get all payments
router.get('/', authenticateToken, async (req, res) => {
  try {
    let whereClause = {};
    
    // If user is parent, only show their children's payments
    if (req.user.role === 'Parent') {
      const children = await Child.findAll({
        where: { user_id: req.user.id },
        attributes: ['id']
      });
      const childIds = children.map(child => child.id);
      whereClause.child_id = childIds;
    }

    const payments = await Payment.findAll({
      where: whereClause,
      include: [
        {
          model: Child,
          attributes: ['id', 'first_name', 'last_name']
        }
      ],
      order: [['payment_date', 'DESC']]
    });
    
    res.json(payments);
  } catch (error) {
    console.error('Error fetching payments:', error);
    res.status(500).json({ message: 'Error fetching payments' });
  }
});

// Get payment by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const payment = await Payment.findByPk(req.params.id, {
      include: [
        {
          model: Child,
          attributes: ['id', 'first_name', 'last_name']
        }
      ]
    });
    
    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }
    
    // If user is parent, ensure they can only view their children's payments
    if (req.user.role === 'Parent') {
      const child = await Child.findByPk(payment.child_id);
      if (!child || child.user_id !== req.user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
    }
    
    res.json(payment);
  } catch (error) {
    console.error('Error fetching payment:', error);
    res.status(500).json({ message: 'Error fetching payment' });
  }
});

// Update payment status (Manager only)
router.put('/:id/status', authenticateToken, isManager, async (req, res) => {
  try {
    const { status } = req.body;
    const payment = await Payment.findByPk(req.params.id);

    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }

    payment.status = status;
    await payment.save();

    res.json({ message: 'Payment status updated successfully', payment });
  } catch (error) {
    console.error('Error updating payment status:', error);
    res.status(500).json({ message: 'Error updating payment status' });
  }
});

// Update payment (Manager only)
router.put('/:id', authenticateToken, isManager, async (req, res) => {
  try {
    const payment = await Payment.findByPk(req.params.id);

    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }

    const { amount, payment_date, payment_method, description, receipt_number, status } = req.body;
    
    if (amount) payment.amount = amount;
    if (payment_date) payment.payment_date = payment_date;
    if (payment_method) payment.payment_method = payment_method;
    if (description) payment.description = description;
    if (receipt_number) payment.receipt_number = receipt_number;
    if (status) payment.status = status;

    await payment.save();

    res.json({ message: 'Payment updated successfully', payment });
  } catch (error) {
    console.error('Error updating payment:', error);
    res.status(500).json({ message: 'Error updating payment' });
  }
});

// Delete payment (Manager only)
router.delete('/:id', authenticateToken, isManager, async (req, res) => {
  try {
    const payment = await Payment.findByPk(req.params.id);

    if (!payment) {
      return res.status(404).json({ message: 'Payment not found' });
    }

    await payment.destroy();
    res.json({ message: 'Payment deleted successfully' });
  } catch (error) {
    console.error('Error deleting payment:', error);
    res.status(500).json({ message: 'Error deleting payment' });
  }
});

// Get payment summary
router.get('/summary/overview', authenticateToken, async (req, res) => {
  try {
    let whereClause = {};
    
    // If user is parent, only show their children's payments
    if (req.user.role === 'Parent') {
      const children = await Child.findAll({
        where: { user_id: req.user.id },
        attributes: ['id']
      });
      const childIds = children.map(child => child.id);
      whereClause.child_id = childIds;
    }

    const payments = await Payment.findAll({
      where: whereClause
    });
    
    const summary = {
      totalAmount: 0,
      pendingAmount: 0,
      completedAmount: 0,
      failedAmount: 0,
      refundedAmount: 0,
      paymentMethods: {}
    };

    payments.forEach(payment => {
      summary.totalAmount += parseFloat(payment.amount);
      
      if (payment.status === 'pending') {
        summary.pendingAmount += parseFloat(payment.amount);
      } else if (payment.status === 'completed') {
        summary.completedAmount += parseFloat(payment.amount);
      } else if (payment.status === 'failed') {
        summary.failedAmount += parseFloat(payment.amount);
      } else if (payment.status === 'refunded') {
        summary.refundedAmount += parseFloat(payment.amount);
      }

      if (!summary.paymentMethods[payment.payment_method]) {
        summary.paymentMethods[payment.payment_method] = 0;
      }
      summary.paymentMethods[payment.payment_method] += parseFloat(payment.amount);
    });

    res.json(summary);
  } catch (error) {
    console.error('Error fetching payment summary:', error);
    res.status(500).json({ message: 'Error fetching payment summary' });
  }
});

module.exports = router; 