const express = require('express');
const router = express.Router();
const { Budget } = require('../models');
const { authenticateToken } = require('../middleware/auth');

// Middleware to check if user is manager
const isManager = (req, res, next) => {
  if (req.user.role !== 'Manager') {
    return res.status(403).json({ message: 'Access denied. Manager only.' });
  }
  next();
};

// Create new budget entry
router.post('/', authenticateToken, isManager, async (req, res) => {
  try {
    const {
      category,
      amount,
      description,
      date,
      type // 'income' or 'expense'
    } = req.body;

    const budget = await Budget.create({
      category,
      amount,
      description,
      date,
      type
    });

    res.status(201).json({
      message: 'Budget entry created successfully',
      budget
    });
  } catch (error) {
    console.error('Error creating budget entry:', error);
    res.status(500).json({ message: 'Error creating budget entry' });
  }
});

// Get all budget entries
router.get('/', authenticateToken, async (req, res) => {
  try {
    const budgets = await Budget.findAll({
      order: [['date', 'DESC']]
    });
    res.json(budgets);
  } catch (error) {
    console.error('Error fetching budget entries:', error);
    res.status(500).json({ message: 'Error fetching budget entries' });
  }
});

// Get budget entry by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const budget = await Budget.findByPk(req.params.id);
    if (!budget) {
      return res.status(404).json({ message: 'Budget entry not found' });
    }
    res.json(budget);
  } catch (error) {
    console.error('Error fetching budget entry:', error);
    res.status(500).json({ message: 'Error fetching budget entry' });
  }
});

// Update budget entry
router.put('/:id', authenticateToken, isManager, async (req, res) => {
  try {
    const budget = await Budget.findByPk(req.params.id);
    if (!budget) {
      return res.status(404).json({ message: 'Budget entry not found' });
    }

    const { category, amount, description, date, type } = req.body;
    
    if (category) budget.category = category;
    if (amount) budget.amount = amount;
    if (description) budget.description = description;
    if (date) budget.date = date;
    if (type) budget.type = type;

    await budget.save();

    res.json({ message: 'Budget entry updated successfully', budget });
  } catch (error) {
    console.error('Error updating budget entry:', error);
    res.status(500).json({ message: 'Error updating budget entry' });
  }
});

// Delete budget entry
router.delete('/:id', authenticateToken, isManager, async (req, res) => {
  try {
    const budget = await Budget.findByPk(req.params.id);
    if (!budget) {
      return res.status(404).json({ message: 'Budget entry not found' });
    }

    await budget.destroy();
    res.json({ message: 'Budget entry deleted successfully' });
  } catch (error) {
    console.error('Error deleting budget entry:', error);
    res.status(500).json({ message: 'Error deleting budget entry' });
  }
});

// Get budget summary
router.get('/summary/overview', authenticateToken, async (req, res) => {
  try {
    const budgets = await Budget.findAll();
    
    const summary = {
      totalIncome: 0,
      totalExpenses: 0,
      balance: 0,
      categories: {}
    };

    budgets.forEach(budget => {
      if (budget.type === 'income') {
        summary.totalIncome += parseFloat(budget.amount);
      } else {
        summary.totalExpenses += parseFloat(budget.amount);
      }

      if (!summary.categories[budget.category]) {
        summary.categories[budget.category] = {
          income: 0,
          expenses: 0
        };
      }

      if (budget.type === 'income') {
        summary.categories[budget.category].income += parseFloat(budget.amount);
      } else {
        summary.categories[budget.category].expenses += parseFloat(budget.amount);
      }
    });

    summary.balance = summary.totalIncome - summary.totalExpenses;

    res.json(summary);
  } catch (error) {
    console.error('Error fetching budget summary:', error);
    res.status(500).json({ message: 'Error fetching budget summary' });
  }
});

module.exports = router; 