const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { User, Parent, Babysitter } = require('../models');
const { authenticateToken } = require('../middleware/auth');

// Register new user
router.post('/register', async (req, res) => {
  try {
    const { username, password, role, firstName, lastName, email, phoneNumber } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ where: { username } });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }

    // Hash password using the class method
    const password_hash = await User.hashPassword(password);

    // Create user
    const user = await User.create({
      username,
      password_hash,
      role
    });

    // Create profile based on role
    if (role === 'Parent') {
      await Parent.create({
        user_id: user.user_id,
        first_name: firstName,
        last_name: lastName,
        email,
        phone_number: phoneNumber
      });
    } else if (role === 'Babysitter') {
      await Babysitter.create({
        user_id: user.user_id,
        first_name: firstName,
        last_name: lastName,
        email,
        phone_number: phoneNumber,
        nin: 'N/A', // Default value, should be updated later
        date_of_birth: new Date(), // Default value, should be updated later
        next_of_kin_name: 'N/A', // Default value, should be updated later
        next_of_kin_phone: 'N/A' // Default value, should be updated later
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user.user_id, role: user.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: user.user_id,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Error registering user', error: error.message });
  }
});

// Login user
router.post('/login', async (req, res) => {
  try {
    console.log('Login request received:', req.body);
    const { username, password, role } = req.body;

    if (!username || !password) {
      console.log('Missing username or password');
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Find user by username
    const user = await User.findOne({ 
      where: { username }
    });

    console.log('User found:', user ? 'Yes' : 'No');

    if (!user) {
      console.log('User not found');
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Verify password using the instance method
    const isValidPassword = await user.validatePassword(password);
    console.log('Password valid:', isValidPassword ? 'Yes' : 'No');

    if (!isValidPassword) {
      console.log('Invalid password');
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check if role matches (if provided)
    if (role && user.role !== role) {
      console.log('Role mismatch:', user.role, '!=', role);
      return res.status(401).json({ message: 'Invalid role for this user' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user.user_id, role: user.role },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    console.log('Login successful for user:', username);
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.user_id,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Error logging in', error: error.message });
  }
});

// Get current user profile
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      include: [
        { model: Parent, as: 'parent' },
        { model: Babysitter, as: 'babysitter' }
      ]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      id: user.user_id,
      username: user.username,
      role: user.role,
      profile: user.role === 'Parent' ? user.parent : user.babysitter
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ message: 'Error fetching profile', error: error.message });
  }
});

// Get current user data
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      include: [
        { model: Parent, as: 'parent' },
        { model: Babysitter, as: 'babysitter' }
      ]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Return user data with profile
    res.json({
      user: {
        id: user.user_id,
        username: user.username,
        role: user.role,
        profile: user.role === 'Parent' ? user.parent : user.babysitter
      }
    });
  } catch (error) {
    console.error('Error fetching current user:', error);
    res.status(500).json({ message: 'Error fetching current user', error: error.message });
  }
});

module.exports = router; 