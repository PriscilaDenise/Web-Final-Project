const express = require('express');
const router = express.Router();
const { 
  Schedule, 
  Attendance,
  Babysitter,
  Child
} = require('../models');
const { authenticateToken, isManager } = require('../middleware/auth');

// Create babysitter schedule
router.post('/babysitter/schedule', authenticateToken, isManager, async (req, res) => {
  try {
    const {
      babysitter_id,
      schedule_date,
      start_time,
      end_time,
      session_type
    } = req.body;

    const schedule = await Schedule.create({
      babysitter_id,
      schedule_date,
      start_time,
      end_time,
      session_type
    });

    res.status(201).json({
      message: 'Schedule created successfully',
      schedule
    });
  } catch (error) {
    res.status(500).json({ message: 'Error creating schedule', error: error.message });
  }
});

// Get babysitter schedules
router.get('/babysitter/schedule', authenticateToken, async (req, res) => {
  try {
    const schedules = await Schedule.findAll({
      include: [{
        model: Babysitter,
        attributes: ['id', 'user_id']
      }]
    });
    res.json(schedules);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching schedules', error: error.message });
  }
});

// Record babysitter attendance
router.post('/babysitter/check-in', authenticateToken, async (req, res) => {
  try {
    const { schedule_id } = req.body;
    const babysitter_id = req.user.role === 'babysitter' ? req.user.id : req.body.babysitter_id;

    const attendance = await Attendance.create({
      babysitter_id,
      schedule_id,
      check_in_time: new Date(),
      status: 'Present'
    });

    res.status(201).json({
      message: 'Check-in recorded successfully',
      attendance
    });
  } catch (error) {
    res.status(500).json({ message: 'Error recording check-in', error: error.message });
  }
});

// Record babysitter check-out
router.post('/babysitter/check-out', authenticateToken, async (req, res) => {
  try {
    const { attendance_id } = req.body;

    const attendance = await Attendance.findByPk(attendance_id);
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }

    await attendance.update({
      check_out_time: new Date()
    });

    res.json({
      message: 'Check-out recorded successfully',
      attendance
    });
  } catch (error) {
    res.status(500).json({ message: 'Error recording check-out', error: error.message });
  }
});

// Record child attendance
router.post('/child/check-in', authenticateToken, async (req, res) => {
  try {
    const {
      child_id,
      babysitter_id,
      session_date,
      session_type
    } = req.body;

    const attendance = await Attendance.create({
      child_id,
      babysitter_id,
      check_in_time: new Date(),
      session_date,
      session_type
    });

    res.status(201).json({
      message: 'Child check-in recorded successfully',
      attendance
    });
  } catch (error) {
    res.status(500).json({ message: 'Error recording child check-in', error: error.message });
  }
});

// Record child check-out
router.post('/child/check-out', authenticateToken, async (req, res) => {
  try {
    const { attendance_id } = req.body;

    const attendance = await Attendance.findByPk(attendance_id);
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }

    await attendance.update({
      check_out_time: new Date()
    });

    res.json({
      message: 'Child check-out recorded successfully',
      attendance
    });
  } catch (error) {
    res.status(500).json({ message: 'Error recording child check-out', error: error.message });
  }
});

// Get child attendance records
router.get('/child', authenticateToken, async (req, res) => {
  try {
    let whereClause = {};
    
    // If user is parent, only show their children's attendance
    if (req.user.role === 'parent') {
      const children = await Child.findAll({
        where: { user_id: req.user.id },
        attributes: ['id']
      });
      const childIds = children.map(child => child.id);
      whereClause.child_id = childIds;
    }

    const attendance = await Attendance.findAll({
      where: whereClause,
      include: [
        {
          model: Child,
          attributes: ['id', 'user_id']
        },
        {
          model: Babysitter,
          attributes: ['id', 'user_id']
        }
      ]
    });

    res.json(attendance);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching child attendance', error: error.message });
  }
});

// Get all child attendance records
router.get('/children', authenticateToken, async (req, res) => {
  try {
    const attendance = await Attendance.findAll({
      include: [{
        model: Child,
        attributes: ['id', 'user_id']
      }]
    });
    res.json(attendance);
  } catch (error) {
    console.error('Error fetching child attendance:', error);
    res.status(500).json({ message: 'Error fetching child attendance' });
  }
});

// Get child attendance by ID
router.get('/children/:id', authenticateToken, async (req, res) => {
  try {
    const attendance = await Attendance.findByPk(req.params.id, {
      include: [{
        model: Child,
        attributes: ['id', 'user_id']
      }]
    });
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }
    res.json(attendance);
  } catch (error) {
    console.error('Error fetching child attendance:', error);
    res.status(500).json({ message: 'Error fetching child attendance' });
  }
});

// Create new child attendance record
router.post('/children', authenticateToken, async (req, res) => {
  try {
    const { child_id, session_date, session_type, check_in_time, check_out_time } = req.body;
    
    // Check if child exists
    const child = await Child.findByPk(child_id);
    if (!child) {
      return res.status(404).json({ message: 'Child not found' });
    }

    const attendance = await Attendance.create({
      child_id,
      session_date,
      session_type,
      check_in_time,
      check_out_time
    });

    res.status(201).json(attendance);
  } catch (error) {
    console.error('Error creating child attendance:', error);
    res.status(500).json({ message: 'Error creating child attendance' });
  }
});

// Update child attendance
router.put('/children/:id', authenticateToken, async (req, res) => {
  try {
    const { session_date, session_type, check_in_time, check_out_time } = req.body;
    const attendance = await Attendance.findByPk(req.params.id);
    
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }

    await attendance.update({
      session_date,
      session_type,
      check_in_time,
      check_out_time
    });

    res.json(attendance);
  } catch (error) {
    console.error('Error updating child attendance:', error);
    res.status(500).json({ message: 'Error updating child attendance' });
  }
});

// Get all babysitter attendance records
router.get('/babysitters', authenticateToken, async (req, res) => {
  try {
    const attendance = await Attendance.findAll({
      include: [{
        model: Babysitter,
        attributes: ['id', 'user_id']
      }]
    });
    res.json(attendance);
  } catch (error) {
    console.error('Error fetching babysitter attendance:', error);
    res.status(500).json({ message: 'Error fetching babysitter attendance' });
  }
});

// Get babysitter attendance by ID
router.get('/babysitters/:id', authenticateToken, async (req, res) => {
  try {
    const attendance = await Attendance.findByPk(req.params.id, {
      include: [{
        model: Babysitter,
        attributes: ['id', 'user_id']
      }]
    });
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }
    res.json(attendance);
  } catch (error) {
    console.error('Error fetching babysitter attendance:', error);
    res.status(500).json({ message: 'Error fetching babysitter attendance' });
  }
});

// Create new babysitter attendance record
router.post('/babysitters', authenticateToken, async (req, res) => {
  try {
    const { babysitter_id, schedule_id, check_in_time, check_out_time, status } = req.body;
    
    // Check if babysitter exists
    const babysitter = await Babysitter.findByPk(babysitter_id);
    if (!babysitter) {
      return res.status(404).json({ message: 'Babysitter not found' });
    }

    const attendance = await Attendance.create({
      babysitter_id,
      schedule_id,
      check_in_time,
      check_out_time,
      status
    });

    res.status(201).json(attendance);
  } catch (error) {
    console.error('Error creating babysitter attendance:', error);
    res.status(500).json({ message: 'Error creating babysitter attendance' });
  }
});

// Update babysitter attendance
router.put('/babysitters/:id', authenticateToken, async (req, res) => {
  try {
    const { check_in_time, check_out_time, status } = req.body;
    const attendance = await Attendance.findByPk(req.params.id);
    
    if (!attendance) {
      return res.status(404).json({ message: 'Attendance record not found' });
    }

    await attendance.update({
      check_in_time,
      check_out_time,
      status
    });

    res.json(attendance);
  } catch (error) {
    console.error('Error updating babysitter attendance:', error);
    res.status(500).json({ message: 'Error updating babysitter attendance' });
  }
});

module.exports = router; 