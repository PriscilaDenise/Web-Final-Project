const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRole } = require('../middleware/auth');
const Babysitter = require('../models/Babysitter');
const User = require('../models/User');
const Schedule = require('../models/Schedule');
const Attendance = require('../models/Attendance');

// Get all babysitters
router.get('/', authenticateToken, async (req, res) => {
  try {
    const babysitters = await Babysitter.findAll({
      include: [{
        model: User,
        attributes: ['id', 'name', 'email', 'phone']
      }]
    });
    res.json(babysitters);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get babysitter by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const babysitter = await Babysitter.findByPk(req.params.id, {
      include: [{
        model: User,
        attributes: ['id', 'name', 'email', 'phone']
      }]
    });

    if (!babysitter) {
      return res.status(404).json({ message: 'Babysitter not found' });
    }

    res.json(babysitter);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create new babysitter (Manager only)
router.post('/', authenticateToken, authorizeRole('Manager'), async (req, res) => {
  try {
    const { userId, qualifications, experience, hourlyRate } = req.body;

    // Check if user exists
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if user is already a babysitter
    const existingBabysitter = await Babysitter.findOne({ where: { userId } });
    if (existingBabysitter) {
      return res.status(400).json({ message: 'User is already a babysitter' });
    }

    const babysitter = await Babysitter.create({
      userId,
      qualifications,
      experience,
      hourlyRate
    });

    res.status(201).json(babysitter);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update babysitter (Manager only)
router.put('/:id', authenticateToken, authorizeRole('Manager'), async (req, res) => {
  try {
    const { qualifications, experience, hourlyRate } = req.body;
    const babysitter = await Babysitter.findByPk(req.params.id);

    if (!babysitter) {
      return res.status(404).json({ message: 'Babysitter not found' });
    }

    await babysitter.update({
      qualifications,
      experience,
      hourlyRate
    });

    res.json(babysitter);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete babysitter (Manager only)
router.delete('/:id', authenticateToken, authorizeRole('Manager'), async (req, res) => {
  try {
    const babysitter = await Babysitter.findByPk(req.params.id);

    if (!babysitter) {
      return res.status(404).json({ message: 'Babysitter not found' });
    }

    await babysitter.destroy();
    res.json({ message: 'Babysitter deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get babysitter schedule
router.get('/:id/schedule', authenticateToken, async (req, res) => {
  try {
    const schedule = await Schedule.findAll({
      where: { babysitterId: req.params.id }
    });
    res.json(schedule);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get babysitter attendance
router.get('/:id/attendance', authenticateToken, async (req, res) => {
  try {
    const attendance = await Attendance.findAll({
      where: { babysitterId: req.params.id }
    });
    res.json(attendance);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router; 