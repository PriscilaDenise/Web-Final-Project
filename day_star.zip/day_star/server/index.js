const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const sequelize = require('./config/database');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const babysitterRoutes = require('./routes/babysitters');
const childRoutes = require('./routes/children');
const attendanceRoutes = require('./routes/attendance');
const paymentRoutes = require('./routes/payments');
const incidentRoutes = require('./routes/incidents');
const budgetRoutes = require('./routes/budgets');
const notificationRoutes = require('./routes/notifications');

// Import models and associations
require('./models/associations');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/babysitters', babysitterRoutes);
app.use('/api/children', childRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/incidents', incidentRoutes);
app.use('/api/budgets', budgetRoutes);
app.use('/api/notifications', notificationRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something broke!', error: err.message });
});

const PORT = process.env.PORT || 5000;

// Function to drop tables in correct order
async function dropTablesInOrder() {
  try {
    // Disable foreign key checks
    await sequelize.query('SET FOREIGN_KEY_CHECKS = 0');
    
    // Drop all tables
    await sequelize.query('DROP TABLE IF EXISTS financial_transactions');
    await sequelize.query('DROP TABLE IF EXISTS payments');
    await sequelize.query('DROP TABLE IF EXISTS incidents');
    await sequelize.query('DROP TABLE IF EXISTS attendance');
    await sequelize.query('DROP TABLE IF EXISTS children');
    await sequelize.query('DROP TABLE IF EXISTS babysitters');
    await sequelize.query('DROP TABLE IF EXISTS parents');
    await sequelize.query('DROP TABLE IF EXISTS users');
    
    // Re-enable foreign key checks
    await sequelize.query('SET FOREIGN_KEY_CHECKS = 1');
    
    console.log('All tables dropped successfully');
  } catch (error) {
    console.error('Error dropping tables:', error);
    throw error;
  }
}

// Sync database and start server
async function initializeDatabase() {
  try {
    // Drop existing tables
    await dropTablesInOrder();
    
    // Sync all models
    await sequelize.sync({ force: false });
    console.log('Database synced successfully');

    // Create test users
    const User = require('./models/User');
    const Parent = require('./models/Parent');
    const Babysitter = require('./models/Babysitter');

    // Create admin user
    const adminUser = await User.create({
      username: 'admin',
      password_hash: await User.hashPassword('admin123'),
      role: 'Manager'
    });

    // Create Oscar user
    const oscarUser = await User.create({
      username: 'oscar',
      password_hash: await User.hashPassword('oscar123'),
      role: 'Manager'
    });

    // Create parent user
    const parentUser = await User.create({
      username: 'parent',
      password_hash: await User.hashPassword('parent123'),
      role: 'Parent'
    });

    // Create parent profile
    await Parent.create({
      user_id: parentUser.user_id,
      first_name: 'John',
      last_name: 'Doe',
      email: 'john.doe@example.com',
      phone_number: '1234567890',
      address: '123 Main St',
      emergency_contact_name: 'Jane Doe',
      emergency_contact_phone: '0987654321'
    });

    // Create babysitter user
    const babysitterUser = await User.create({
      username: 'babysitter',
      password_hash: await User.hashPassword('babysitter123'),
      role: 'Babysitter'
    });

    // Create babysitter profile
    await Babysitter.create({
      user_id: babysitterUser.user_id,
      first_name: 'Jane',
      last_name: 'Smith',
      email: 'jane.smith@example.com',
      phone_number: '1234567890',
      nin: 'ABC123456',
      date_of_birth: '1990-01-01',
      next_of_kin_name: 'John Smith',
      next_of_kin_phone: '0987654321'
    });

    console.log('Test users created successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

// Start server
initializeDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch(err => {
    console.error('Unable to start server:', err);
    process.exit(1);
  }); 