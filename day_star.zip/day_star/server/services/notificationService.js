const Notification = require('../models/Notification');
const User = require('../models/User');
const { Op } = require('sequelize');

class NotificationService {
  static async createNotification(userId, type, title, message, metadata = null) {
    return await Notification.create({
      userId,
      type,
      title,
      message,
      metadata
    });
  }

  static async sendChildStatusNotification(childId, type, title, message) {
    const child = await Child.findByPk(childId, {
      include: [{
        model: User,
        as: 'parent',
        where: { role: 'parent' }
      }]
    });

    if (child && child.parent) {
      await this.createNotification(
        child.parent.id,
        type,
        title,
        message,
        { childId }
      );
    }
  }

  static async sendPaymentReminder(parentId, childId, amount) {
    await this.createNotification(
      parentId,
      'PAYMENT_REMINDER',
      'Payment Reminder',
      `Your payment of ${amount} for daycare services is due soon.`,
      { childId, amount }
    );
  }

  static async sendOverduePaymentNotification(parentId, childId, amount) {
    await this.createNotification(
      parentId,
      'PAYMENT_OVERDUE',
      'Overdue Payment',
      `Your payment of ${amount} for daycare services is overdue. Please make the payment as soon as possible.`,
      { childId, amount }
    );
  }

  static async sendBudgetAlert(managerId, category, amount, threshold) {
    await this.createNotification(
      managerId,
      'BUDGET_ALERT',
      'Budget Threshold Exceeded',
      `The ${category} expenses have exceeded the threshold of ${threshold}. Current amount: ${amount}`,
      { category, amount, threshold }
    );
  }

  static async checkAndSendBudgetAlerts() {
    const budgets = await Budget.findAll();
    const expenses = await Expense.findAll({
      where: {
        createdAt: {
          [Op.gte]: new Date(new Date() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
        }
      },
      group: ['category']
    });

    for (const budget of budgets) {
      const categoryExpense = expenses.find(e => e.category === budget.category);
      if (categoryExpense && categoryExpense.amount > budget.amount) {
        await this.sendBudgetAlert(
          budget.managerId,
          budget.category,
          categoryExpense.amount,
          budget.amount
        );
      }
    }
  }
}

module.exports = NotificationService; 