import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to requests if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Auth services
export const login = async (credentials) => {
  try {
    console.log('Attempting login with:', credentials);
    const loginData = {
      username: credentials.username,
      password: credentials.password,
      role: credentials.role
    };
    console.log('Sending login request to:', `${API_URL}/auth/login`);
    const response = await api.post('/auth/login', loginData);
    console.log('Login response:', response.data);
    
    if (response.data && response.data.token) {
      // Store the token in localStorage
      localStorage.setItem('token', response.data.token);
      // Store user info if provided
      if (response.data.user) {
        localStorage.setItem('user', JSON.stringify(response.data.user));
      }
      return response.data;
    } else {
      throw new Error('Invalid response format: missing token');
    }
  } catch (error) {
    console.error('Login error:', error);
    if (error.response) {
      console.error('Error response data:', error.response.data);
      console.error('Error response status:', error.response.status);
      console.error('Error response headers:', error.response.headers);
    } else if (error.request) {
      console.error('Error request:', error.request);
    } else {
      console.error('Error message:', error.message);
    }
    throw error;
  }
};

export const register = (userData) => api.post('/auth/register', userData);
export const getCurrentUser = async () => {
  try {
    const response = await api.get('/auth/me');
    if (response.data && response.data.user) {
      return response.data.user;
    }
    throw new Error('Invalid user data received');
  } catch (error) {
    console.error('Error getting current user:', error);
    throw error;
  }
};

// Babysitter services
export const registerBabysitter = (data) => api.post('/babysitters', data);
export const getAllBabysitters = async () => {
  const response = await api.get('/babysitters');
  return response.data;
};

export const getBabysitterById = async (id) => {
  const response = await api.get(`/babysitters/${id}`);
  return response.data;
};

export const createBabysitter = async (data) => {
  const response = await api.post('/babysitters', data);
  return response.data;
};

export const updateBabysitter = async (id, data) => {
  const response = await api.put(`/babysitters/${id}`, data);
  return response.data;
};

export const deleteBabysitter = async (id) => {
  const response = await api.delete(`/babysitters/${id}`);
  return response.data;
};

export const getBabysitterSchedule = async (id) => {
  const response = await api.get(`/babysitters/${id}/schedule`);
  return response.data;
};

export const getBabysitterAttendance = async (id) => {
  const response = await api.get(`/babysitters/${id}/attendance`);
  return response.data;
};

// Child services
export const registerChild = (data) => api.post('/children', data);
export const getAllChildren = async () => {
  try {
    const response = await api.get('/children');
    return response.data;
  } catch (error) {
    console.error('Error fetching children:', error);
    throw error;
  }
};

export const getChildById = async (id) => {
  try {
    const response = await api.get(`/children/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching child:', error);
    throw error;
  }
};

export const createChild = async (childData) => {
  try {
    const response = await api.post('/children', childData);
    return response.data;
  } catch (error) {
    console.error('Error creating child:', error);
    throw error;
  }
};

export const updateChild = async (id, childData) => {
  try {
    const response = await api.put(`/children/${id}`, childData);
    return response.data;
  } catch (error) {
    console.error('Error updating child:', error);
    throw error;
  }
};

export const deleteChild = async (id) => {
  try {
    const response = await api.delete(`/children/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error deleting child:', error);
    throw error;
  }
};

// Attendance services
export const createBabysitterSchedule = (data) => api.post('/attendance/babysitter/schedule', data);
export const getBabysitterSchedules = () => api.get('/attendance/babysitter/schedule');
export const recordBabysitterCheckIn = (data) => api.post('/attendance/babysitter/check-in', data);
export const recordBabysitterCheckOut = (data) => api.post('/attendance/babysitter/check-out', data);
export const recordChildCheckIn = (data) => api.post('/attendance/child/check-in', data);
export const recordChildCheckOut = (data) => api.post('/attendance/child/check-out', data);
export const getChildAttendance = () => api.get('/attendance/child');
export const createAttendance = async (data) => {
  const response = await api.post('/attendance', data);
  return response.data;
};
export const updateAttendance = async (id, data) => {
  const response = await api.put(`/attendance/${id}`, data);
  return response.data;
};
export const deleteAttendance = async (id) => {
  const response = await api.delete(`/attendance/${id}`);
  return response.data;
};
export const getAllAttendance = async () => {
  const response = await api.get('/attendance');
  return response.data;
};

// Incident services
export const reportIncident = (data) => api.post('/incidents', data);
export const getAllIncidents = async () => {
  const response = await api.get('/incidents');
  return response.data;
};

export const getIncident = (id) => api.get(`/incidents/${id}`);
export const updateIncidentStatus = (id, data) => api.put(`/incidents/${id}/status`, data);

// Payment services
export const createBabysitterPayment = (data) => api.post('/payments/babysitter', data);
export const createParentalPayment = (data) => api.post('/payments/parent', data);
export const createPayment = async (data) => {
  const response = await api.post('/payments', data);
  return response.data;
};
export const getAllPayments = () => api.get('/payments');
export const updatePaymentStatus = (id, data) => api.put(`/payments/${id}/status`, data);
export const updatePayment = async (id, data) => {
  const response = await api.put(`/payments/${id}`, data);
  return response.data;
};
export const getDailyPaymentSummary = (date) => api.get(`/payments/summary/daily?date=${date}`);
export const deletePayment = async (id) => {
  const response = await api.delete(`/payments/${id}`);
  return response.data;
};

// Incident API functions
export const getChildIncidents = async (childId) => {
  const response = await api.get(`/incidents/child/${childId}`);
  return response.data;
};

export const createIncident = async (incidentData) => {
  const response = await api.post('/incidents', incidentData);
  return response.data;
};

export const updateIncident = async (id, incidentData) => {
  const response = await api.put(`/incidents/${id}`, incidentData);
  return response.data;
};

export const deleteIncident = async (id) => {
  const response = await api.delete(`/incidents/${id}`);
  return response.data;
};

// Budget API functions
export const getAllBudgets = async () => {
  const response = await api.get('/budgets');
  return response.data;
};

export const getBudgetSummary = async () => {
  const response = await api.get('/budgets/summary/overview');
  return response.data;
};

export const createBudget = async (budgetData) => {
  const response = await api.post('/budgets', budgetData);
  return response.data;
};

export const updateBudget = async (id, budgetData) => {
  const response = await api.put(`/budgets/${id}`, budgetData);
  return response.data;
};

export const deleteBudget = async (id) => {
  const response = await api.delete(`/budgets/${id}`);
  return response.data;
};

// Financial Reporting API functions
export const getFinancialSummary = async (period) => {
  const response = await api.get(`/financial/summary?period=${period}`);
  return response.data;
};

export const getBudgetAdherence = async (period) => {
  const response = await api.get(`/financial/budget-adherence?period=${period}`);
  return response.data;
};

export const getSpendingTrends = async (period) => {
  const response = await api.get(`/financial/spending-trends?period=${period}`);
  return response.data;
};

export const exportFinancialData = async (period, format) => {
  const response = await api.get(`/financial/export?period=${period}&format=${format}`, {
    responseType: 'blob'
  });
  return response;
};

// Notification API functions
export const getNotifications = async () => {
  const response = await api.get('/notifications');
  return response.data;
};

export const markNotificationAsRead = async (id) => {
  const response = await api.put(`/notifications/${id}/read`);
  return response.data;
};

export const markAllNotificationsAsRead = async () => {
  const response = await api.put('/notifications/read-all');
  return response.data;
};

export const deleteNotification = async (id) => {
  const response = await api.delete(`/notifications/${id}`);
  return response.data;
};

// User services
export const getAllUsers = async () => {
  const response = await api.get('/users');
  return response.data;
}; 