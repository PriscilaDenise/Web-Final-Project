import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  CircularProgress,
  Alert
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import { 
  getAllBabysitters, 
  createBabysitter, 
  updateBabysitter, 
  deleteBabysitter,
  getAllUsers
} from '../services/api';

const BabysitterManagement = () => {
  const [babysitters, setBabysitters] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedBabysitter, setSelectedBabysitter] = useState(null);
  const [formData, setFormData] = useState({
    userId: '',
    qualifications: '',
    experience: '',
    hourlyRate: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [babysittersData, usersData] = await Promise.all([
        getAllBabysitters(),
        getAllUsers()
      ]);
      
      // Filter users to only include those who are not already babysitters
      const availableUsers = usersData.filter(user => 
        user.role === 'babysitter' && 
        !babysittersData.some(babysitter => babysitter.userId === user.id)
      );
      
      setBabysitters(babysittersData);
      setUsers(availableUsers);
      setError(null);
    } catch (err) {
      setError('Failed to fetch data. Please try again later.');
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (babysitter = null) => {
    if (babysitter) {
      setSelectedBabysitter(babysitter);
      setFormData({
        userId: babysitter.userId,
        qualifications: babysitter.qualifications || '',
        experience: babysitter.experience || '',
        hourlyRate: babysitter.hourlyRate || ''
      });
    } else {
      setSelectedBabysitter(null);
      setFormData({
        userId: '',
        qualifications: '',
        experience: '',
        hourlyRate: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedBabysitter(null);
    setFormData({
      userId: '',
      qualifications: '',
      experience: '',
      hourlyRate: ''
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedBabysitter) {
        await updateBabysitter(selectedBabysitter.id, formData);
      } else {
        await createBabysitter(formData);
      }
      handleCloseDialog();
      fetchData();
    } catch (err) {
      setError('Failed to save babysitter. Please try again.');
      console.error('Error saving babysitter:', err);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this babysitter?')) {
      try {
        await deleteBabysitter(id);
        fetchData();
      } catch (err) {
        setError('Failed to delete babysitter. Please try again.');
        console.error('Error deleting babysitter:', err);
      }
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4">Babysitter Management</Typography>
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Add Babysitter
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Qualifications</TableCell>
              <TableCell>Experience (Years)</TableCell>
              <TableCell>Hourly Rate</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {babysitters.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} align="center">No babysitters found</TableCell>
              </TableRow>
            ) : (
              babysitters.map((babysitter) => (
                <TableRow key={babysitter.id}>
                  <TableCell>{babysitter.User?.name || 'N/A'}</TableCell>
                  <TableCell>{babysitter.User?.email || 'N/A'}</TableCell>
                  <TableCell>{babysitter.User?.phone || 'N/A'}</TableCell>
                  <TableCell>{babysitter.qualifications || 'N/A'}</TableCell>
                  <TableCell>{babysitter.experience || 'N/A'}</TableCell>
                  <TableCell>${babysitter.hourlyRate || '0.00'}</TableCell>
                  <TableCell>{babysitter.isActive ? 'Active' : 'Inactive'}</TableCell>
                  <TableCell>
                    <IconButton 
                      color="primary" 
                      onClick={() => handleOpenDialog(babysitter)}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton 
                      color="error" 
                      onClick={() => handleDelete(babysitter.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedBabysitter ? 'Edit Babysitter' : 'Add New Babysitter'}
        </DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <Grid container spacing={2}>
              {!selectedBabysitter && (
                <Grid item xs={12}>
                  <FormControl fullWidth>
                    <InputLabel>User</InputLabel>
                    <Select
                      name="userId"
                      value={formData.userId}
                      onChange={handleInputChange}
                      required
                    >
                      {users.map(user => (
                        <MenuItem key={user.id} value={user.id}>
                          {user.name} ({user.email})
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              )}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Qualifications"
                  name="qualifications"
                  value={formData.qualifications}
                  onChange={handleInputChange}
                  multiline
                  rows={3}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Experience (Years)"
                  name="experience"
                  type="number"
                  value={formData.experience}
                  onChange={handleInputChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Hourly Rate ($)"
                  name="hourlyRate"
                  type="number"
                  value={formData.hourlyRate}
                  onChange={handleInputChange}
                  required
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button type="submit" variant="contained" color="primary">
              {selectedBabysitter ? 'Update' : 'Add'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};

export default BabysitterManagement; 