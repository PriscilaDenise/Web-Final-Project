import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Tabs,
  Tab,
  CircularProgress
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import BudgetManagement from '../components/BudgetManagement';
import IncidentManagement from '../components/IncidentManagement';
import FinancialReports from '../components/FinancialReports';
import {
  getBabysitterSchedules,
  getChildAttendance,
  getAllIncidents,
  getAllPayments
} from '../services/api';

const ManagerDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [schedule, setSchedule] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [payments, setPayments] = useState([]);
  const [activeTab, setActiveTab] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [scheduleData, attendanceData, incidentsData, paymentsData] = await Promise.all([
        getBabysitterSchedules(),
        getChildAttendance(),
        getAllIncidents(),
        getAllPayments()
      ]);

      setSchedule(scheduleData);
      setAttendance(attendanceData);
      setIncidents(incidentsData);
      setPayments(paymentsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'success';
      case 'pending': return 'warning';
      case 'cancelled': return 'error';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Manager Dashboard
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="Today's Schedule" />
          <Tab label="Attendance" />
          <Tab label="Incidents" />
          <Tab label="Payments" />
          <Tab label="Budget" />
          <Tab label="Financial Reports" />
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Time</TableCell>
                <TableCell>Child</TableCell>
                <TableCell>Babysitter</TableCell>
                <TableCell>Activity</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {schedule.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    {new Date(item.start_time).toLocaleTimeString()} - 
                    {new Date(item.end_time).toLocaleTimeString()}
                  </TableCell>
                  <TableCell>
                    {item.Child.first_name} {item.Child.last_name}
                  </TableCell>
                  <TableCell>
                    {item.Babysitter.first_name} {item.Babysitter.last_name}
                  </TableCell>
                  <TableCell>{item.activity}</TableCell>
                  <TableCell>
                    <Chip
                      label={item.status}
                      color={getStatusColor(item.status)}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 1 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Child</TableCell>
                <TableCell>Check-in Time</TableCell>
                <TableCell>Check-out Time</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {attendance.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>
                    {record.Child.first_name} {record.Child.last_name}
                  </TableCell>
                  <TableCell>
                    {record.check_in ? new Date(record.check_in).toLocaleTimeString() : '-'}
                  </TableCell>
                  <TableCell>
                    {record.check_out ? new Date(record.check_out).toLocaleTimeString() : '-'}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={record.status}
                      color={record.status === 'present' ? 'success' : 'error'}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 2 && (
        <IncidentManagement />
      )}

      {activeTab === 3 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Parent</TableCell>
                <TableCell>Child</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {payments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell>
                    {new Date(payment.payment_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {payment.Parent.first_name} {payment.Parent.last_name}
                  </TableCell>
                  <TableCell>
                    {payment.Child.first_name} {payment.Child.last_name}
                  </TableCell>
                  <TableCell>
                    UGX {parseFloat(payment.amount).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={payment.status}
                      color={payment.status === 'paid' ? 'success' : 'warning'}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 4 && (
        <BudgetManagement />
      )}

      {activeTab === 5 && (
        <FinancialReports />
      )}
    </Box>
  );
};

export default ManagerDashboard; 