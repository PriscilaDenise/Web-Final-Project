import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Container,
  Box,
  Typography,
  TextField,
  Button,
  Alert,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Divider
} from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { register } from '../services/api';

// Base validation schema
const baseValidationSchema = yup.object({
  username: yup
    .string()
    .required('Username is required')
    .min(3, 'Username must be at least 3 characters'),
  password: yup
    .string()
    .required('Password is required')
    .min(6, 'Password must be at least 6 characters'),
  confirmPassword: yup
    .string()
    .required('Please confirm your password')
    .oneOf([yup.ref('password')], 'Passwords must match'),
  role: yup
    .string()
    .required('Role is required')
    .oneOf(['Manager', 'Parent', 'Babysitter'], 'Invalid role selected')
});

// Parent-specific validation
const parentValidationSchema = baseValidationSchema.shape({
  firstName: yup.string().required('First name is required'),
  lastName: yup.string().required('Last name is required'),
  email: yup.string().email('Invalid email format').required('Email is required'),
  phoneNumber: yup.string().required('Phone number is required')
});

// Babysitter-specific validation
const babysitterValidationSchema = baseValidationSchema.shape({
  firstName: yup.string().required('First name is required'),
  lastName: yup.string().required('Last name is required'),
  email: yup.string().email('Invalid email format').required('Email is required'),
  phoneNumber: yup.string().required('Phone number is required'),
  nin: yup.string().required('National ID is required'),
  dateOfBirth: yup.date().required('Date of birth is required'),
  nextOfKinName: yup.string().required('Next of kin name is required'),
  nextOfKinPhone: yup.string().required('Next of kin phone is required')
});

// Manager-specific validation
const managerValidationSchema = baseValidationSchema.shape({
  firstName: yup.string().required('First name is required'),
  lastName: yup.string().required('Last name is required'),
  email: yup.string().email('Invalid email format').required('Email is required'),
  phoneNumber: yup.string().required('Phone number is required')
});

const Register = () => {
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [validationSchema, setValidationSchema] = useState(baseValidationSchema);

  const formik = useFormik({
    initialValues: {
      username: '',
      password: '',
      confirmPassword: '',
      role: '',
      // Parent fields
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      // Babysitter additional fields
      nin: '',
      dateOfBirth: '',
      nextOfKinName: '',
      nextOfKinPhone: ''
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        const { confirmPassword, ...registerData } = values;
        await register(registerData);
        navigate('/login', { state: { message: 'Registration successful! Please login.' } });
      } catch (err) {
        setError(err.response?.data?.message || 'An error occurred during registration');
      }
    }
  });

  // Update validation schema when role changes
  const handleRoleChange = (event) => {
    const newRole = event.target.value;
    formik.setFieldValue('role', newRole);
    
    // Update validation schema based on role
    switch (newRole) {
      case 'Parent':
        setValidationSchema(parentValidationSchema);
        break;
      case 'Babysitter':
        setValidationSchema(babysitterValidationSchema);
        break;
      case 'Manager':
        setValidationSchema(managerValidationSchema);
        break;
      default:
        setValidationSchema(baseValidationSchema);
    }
  };

  // Render role-specific fields
  const renderRoleSpecificFields = () => {
    const role = formik.values.role;

    if (role === 'Parent' || role === 'Manager') {
      return (
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="firstName"
              name="firstName"
              label="First Name"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              error={formik.touched.firstName && Boolean(formik.errors.firstName)}
              helperText={formik.touched.firstName && formik.errors.firstName}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="lastName"
              name="lastName"
              label="Last Name"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              helperText={formik.touched.lastName && formik.errors.lastName}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="email"
              name="email"
              label="Email Address"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="phoneNumber"
              name="phoneNumber"
              label="Phone Number"
              value={formik.values.phoneNumber}
              onChange={formik.handleChange}
              error={formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)}
              helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
            />
          </Grid>
        </Grid>
      );
    }

    if (role === 'Babysitter') {
      return (
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="firstName"
              name="firstName"
              label="First Name"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              error={formik.touched.firstName && Boolean(formik.errors.firstName)}
              helperText={formik.touched.firstName && formik.errors.firstName}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="lastName"
              name="lastName"
              label="Last Name"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              helperText={formik.touched.lastName && formik.errors.lastName}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="email"
              name="email"
              label="Email Address"
              type="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="phoneNumber"
              name="phoneNumber"
              label="Phone Number"
              value={formik.values.phoneNumber}
              onChange={formik.handleChange}
              error={formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)}
              helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="nin"
              name="nin"
              label="National ID Number"
              value={formik.values.nin}
              onChange={formik.handleChange}
              error={formik.touched.nin && Boolean(formik.errors.nin)}
              helperText={formik.touched.nin && formik.errors.nin}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="dateOfBirth"
              name="dateOfBirth"
              label="Date of Birth"
              type="date"
              InputLabelProps={{ shrink: true }}
              value={formik.values.dateOfBirth}
              onChange={formik.handleChange}
              error={formik.touched.dateOfBirth && Boolean(formik.errors.dateOfBirth)}
              helperText={formik.touched.dateOfBirth && formik.errors.dateOfBirth}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="nextOfKinName"
              name="nextOfKinName"
              label="Next of Kin Name"
              value={formik.values.nextOfKinName}
              onChange={formik.handleChange}
              error={formik.touched.nextOfKinName && Boolean(formik.errors.nextOfKinName)}
              helperText={formik.touched.nextOfKinName && formik.errors.nextOfKinName}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="nextOfKinPhone"
              name="nextOfKinPhone"
              label="Next of Kin Phone"
              value={formik.values.nextOfKinPhone}
              onChange={formik.handleChange}
              error={formik.touched.nextOfKinPhone && Boolean(formik.errors.nextOfKinPhone)}
              helperText={formik.touched.nextOfKinPhone && formik.errors.nextOfKinPhone}
            />
          </Grid>
        </Grid>
      );
    }

    return null;
  };

  return (
    <Container component="main" maxWidth="md">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center'
        }}
      >
        <Paper
          elevation={3}
          sx={{
            padding: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            width: '100%'
          }}
        >
          <Typography component="h1" variant="h5">
            Daystar Daycare
          </Typography>
          <Typography component="h2" variant="h6" sx={{ mt: 2 }}>
            Sign Up
          </Typography>

          {error && (
            <Alert severity="error" sx={{ mt: 2, width: '100%' }}>
              {error}
            </Alert>
          )}

          <Box component="form" onSubmit={formik.handleSubmit} sx={{ mt: 3, width: '100%' }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  required
                  id="username"
                  label="Username"
                  name="username"
                  autoComplete="username"
                  autoFocus
                  value={formik.values.username}
                  onChange={formik.handleChange}
                  error={formik.touched.username && Boolean(formik.errors.username)}
                  helperText={formik.touched.username && formik.errors.username}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  required
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="new-password"
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  error={formik.touched.password && Boolean(formik.errors.password)}
                  helperText={formik.touched.password && formik.errors.password}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  required
                  name="confirmPassword"
                  label="Confirm Password"
                  type="password"
                  id="confirmPassword"
                  autoComplete="new-password"
                  value={formik.values.confirmPassword}
                  onChange={formik.handleChange}
                  error={formik.touched.confirmPassword && Boolean(formik.errors.confirmPassword)}
                  helperText={formik.touched.confirmPassword && formik.errors.confirmPassword}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel id="role-label">Role</InputLabel>
                  <Select
                    labelId="role-label"
                    id="role"
                    name="role"
                    value={formik.values.role}
                    label="Role"
                    onChange={handleRoleChange}
                    error={formik.touched.role && Boolean(formik.errors.role)}
                  >
                    <MenuItem value="Manager">Manager</MenuItem>
                    <MenuItem value="Parent">Parent</MenuItem>
                    <MenuItem value="Babysitter">Babysitter</MenuItem>
                  </Select>
                  {formik.touched.role && formik.errors.role && (
                    <Typography variant="caption" color="error">
                      {formik.errors.role}
                    </Typography>
                  )}
                </FormControl>
              </Grid>
            </Grid>

            {formik.values.role && (
              <>
                <Divider sx={{ my: 3 }} />
                <Typography variant="h6" sx={{ mb: 2 }}>
                  {formik.values.role} Information
                </Typography>
                {renderRoleSpecificFields()}
              </>
            )}

            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign Up
            </Button>
            <Box sx={{ textAlign: 'center' }}>
              <Link to="/login" style={{ textDecoration: 'none' }}>
                <Typography variant="body2" color="primary">
                  Already have an account? Sign In
                </Typography>
              </Link>
            </Box>
          </Box>
        </Paper>
      </Box>
    </Container>
  );
};

export default Register; 