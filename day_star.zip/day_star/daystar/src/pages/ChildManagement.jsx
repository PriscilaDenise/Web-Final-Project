import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import Layout from '../components/Layout';
import ChildRegistrationForm from '../components/ChildRegistrationForm';
import { getAllChildren, createChild, updateChild, deleteChild } from '../services/api';

const ChildManagement = () => {
  const [children, setChildren] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedChild, setSelectedChild] = useState(null);

  const fetchChildren = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getAllChildren();
      setChildren(data);
    } catch (err) {
      setError('Failed to fetch children');
      console.error('Error fetching children:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChildren();
  }, []);

  const handleOpenDialog = (child = null) => {
    setSelectedChild(child);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedChild(null);
  };

  const handleSubmit = async (values) => {
    try {
      setLoading(true);
      setError(null);
      if (selectedChild) {
        await updateChild(selectedChild.id, values);
        setSuccessMessage('Child information updated successfully');
      } else {
        await createChild(values);
        setSuccessMessage('Child registered successfully');
      }
      handleCloseDialog();
      fetchChildren();
    } catch (err) {
      setError(err.message || 'Failed to save child information');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (childId) => {
    if (window.confirm('Are you sure you want to delete this child?')) {
      try {
        setLoading(true);
        setError(null);
        await deleteChild(childId);
        setSuccessMessage('Child deleted successfully');
        fetchChildren();
      } catch (err) {
        setError(err.message || 'Failed to delete child');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <Layout>
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h4">Child Management</Typography>
          <Button
            variant="contained"
            color="primary"
            onClick={() => handleOpenDialog()}
            disabled={loading}
          >
            Register New Child
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        {successMessage && (
          <Alert severity="success" sx={{ mb: 3 }}>
            {successMessage}
          </Alert>
        )}

        <Paper elevation={3}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Age</TableCell>
                  <TableCell>Gender</TableCell>
                  <TableCell>Parent</TableCell>
                  <TableCell>Emergency Contact</TableCell>
                  <TableCell>Special Needs</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <CircularProgress />
                    </TableCell>
                  </TableRow>
                ) : children.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      No children registered
                    </TableCell>
                  </TableRow>
                ) : (
                  children.map((child) => (
                    <TableRow key={child.id}>
                      <TableCell>{`${child.firstName} ${child.lastName}`}</TableCell>
                      <TableCell>
                        {new Date().getFullYear() - new Date(child.dateOfBirth).getFullYear()}
                      </TableCell>
                      <TableCell>{child.gender}</TableCell>
                      <TableCell>{child.parent?.firstName} {child.parent?.lastName}</TableCell>
                      <TableCell>
                        {child.emergencyContactName}
                        <br />
                        {child.emergencyContactPhone}
                      </TableCell>
                      <TableCell>
                        {child.specialNeeds ? (
                          <Chip label="Yes" color="warning" size="small" />
                        ) : (
                          <Chip label="No" color="success" size="small" />
                        )}
                      </TableCell>
                      <TableCell>
                        <IconButton
                          color="primary"
                          onClick={() => handleOpenDialog(child)}
                          disabled={loading}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          color="error"
                          onClick={() => handleDelete(child.id)}
                          disabled={loading}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      </Box>

      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          {selectedChild ? 'Edit Child Information' : 'Register New Child'}
        </DialogTitle>
        <DialogContent>
          <ChildRegistrationForm
            onSubmit={handleSubmit}
            initialValues={selectedChild}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Layout>
  );
};

export default ChildManagement; 