import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  Tabs,
  Tab,
  CircularProgress
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext'; // Corrected import path
import ReportIncident from '../components/ReportIncident';
import {
  getBabysitterSchedules, // Corrected import
  getChildAttendance,
  getAllIncidents
} from '../services/api';

const BabysitterDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [schedule, setSchedule] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [incidents, setIncidents] = useState([]);
  const [activeTab, setActiveTab] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [scheduleData, attendanceData, incidentsData] = await Promise.all([
        getBabysitterSchedules(user.babysitter.id), // Corrected function call
        getChildAttendance(),
        getAllIncidents()
      ]);

      setSchedule(scheduleData);
      setAttendance(attendanceData);
      setIncidents(incidentsData.filter(incident => 
        incident.babysitter_id === user.babysitter.id
      ));
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'low': return 'success';
      case 'medium': return 'warning';
      case 'high': return 'error';
      default: return 'default';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'resolved': return 'success';
      case 'investigating': return 'info';
      default: return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Babysitter Dashboard
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="Today's Schedule" />
          <Tab label="Attendance" />
          <Tab label="Incidents" />
          <Tab label="Report Incident" />
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Time</TableCell>
                <TableCell>Child</TableCell>
                <TableCell>Activity</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {schedule.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    {new Date(item.start_time).toLocaleTimeString()} - 
                    {new Date(item.end_time).toLocaleTimeString()}
                  </TableCell>
                  <TableCell>
                    {item.Child.first_name} {item.Child.last_name}
                  </TableCell>
                  <TableCell>{item.activity}</TableCell>
                  <TableCell>
                    <Chip
                      label={item.status}
                      color={item.status === 'completed' ? 'success' : 'warning'}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 1 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Child</TableCell>
                <TableCell>Check-in Time</TableCell>
                <TableCell>Check-out Time</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {attendance.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>
                    {record.Child.first_name} {record.Child.last_name}
                  </TableCell>
                  <TableCell>
                    {record.check_in ? new Date(record.check_in).toLocaleTimeString() : '-'}
                  </TableCell>
                  <TableCell>
                    {record.check_out ? new Date(record.check_out).toLocaleTimeString() : '-'}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={record.status}
                      color={record.status === 'present' ? 'success' : 'error'}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 2 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Child</TableCell>
                <TableCell>Description</TableCell>
                <TableCell>Severity</TableCell>
                <TableCell>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {incidents.map((incident) => (
                <TableRow key={incident.id}>
                  <TableCell>
                    {new Date(incident.incident_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    {incident.Child.first_name} {incident.Child.last_name}
                  </TableCell>
                  <TableCell>{incident.description}</TableCell>
                  <TableCell>
                    <Chip
                      label={incident.severity}
                      color={getSeverityColor(incident.severity)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={incident.status}
                      color={getStatusColor(incident.status)}
                      size="small"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 3 && (
        <ReportIncident />
      )}
    </Box>
  );
};

export default BabysitterDashboard; 