import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  CircularProgress,
  Alert,
  Chip,
  Tabs,
  Tab
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import { 
  getAllIncidents, 
  createIncident, 
  updateIncident, 
  deleteIncident,
  getAllChildren,
  getAllBabysitters
} from '../services/api';

const IncidentManagement = () => {
  const [incidents, setIncidents] = useState([]);
  const [children, setChildren] = useState([]);
  const [babysitters, setBabysitters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [formData, setFormData] = useState({
    childId: '',
    babysitterId: '',
    date: new Date().toISOString().split('T')[0],
    time: '',
    type: 'minor',
    description: '',
    actionTaken: '',
    followUp: '',
    status: 'open'
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [incidentsData, childrenData, babysittersData] = await Promise.all([
        getAllIncidents(),
        getAllChildren(),
        getAllBabysitters()
      ]);
      
      setIncidents(incidentsData);
      setChildren(childrenData);
      setBabysitters(babysittersData);
      setError(null);
    } catch (err) {
      setError('Failed to fetch data. Please try again later.');
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleOpenDialog = (incident = null) => {
    if (incident) {
      setSelectedIncident(incident);
      setFormData({
        childId: incident.childId || '',
        babysitterId: incident.babysitterId || '',
        date: incident.date ? new Date(incident.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        time: incident.time || '',
        type: incident.type || 'minor',
        description: incident.description || '',
        actionTaken: incident.actionTaken || '',
        followUp: incident.followUp || '',
        status: incident.status || 'open'
      });
    } else {
      setSelectedIncident(null);
      setFormData({
        childId: '',
        babysitterId: '',
        date: new Date().toISOString().split('T')[0],
        time: '',
        type: 'minor',
        description: '',
        actionTaken: '',
        followUp: '',
        status: 'open'
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedIncident(null);
    setFormData({
      childId: '',
      babysitterId: '',
      date: new Date().toISOString().split('T')[0],
      time: '',
      type: 'minor',
      description: '',
      actionTaken: '',
      followUp: '',
      status: 'open'
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedIncident) {
        await updateIncident(selectedIncident.id, formData);
      } else {
        await createIncident(formData);
      }
      handleCloseDialog();
      fetchData();
    } catch (err) {
      setError('Failed to save incident. Please try again.');
      console.error('Error saving incident:', err);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this incident?')) {
      try {
        await deleteIncident(id);
        fetchData();
      } catch (err) {
        setError('Failed to delete incident. Please try again.');
        console.error('Error deleting incident:', err);
      }
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'minor':
        return 'info';
      case 'moderate':
        return 'warning';
      case 'severe':
        return 'error';
      default:
        return 'default';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'open':
        return 'error';
      case 'in_progress':
        return 'warning';
      case 'resolved':
        return 'success';
      default:
        return 'default';
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const getChildName = (childId) => {
    const child = children.find(c => c.id === childId);
    return child ? `${child.firstName} ${child.lastName}` : 'Unknown';
  };

  const getBabysitterName = (babysitterId) => {
    const babysitter = babysitters.find(b => b.id === babysitterId);
    return babysitter ? `${babysitter.firstName} ${babysitter.lastName}` : 'Unknown';
  };

  const filteredIncidents = tabValue === 0 
    ? incidents.filter(incident => incident.status === 'open')
    : incidents;

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4">Incident Management</Typography>
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          Report Incident
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
        >
          <Tab label="Open Incidents" />
          <Tab label="All Incidents" />
        </Tabs>
      </Paper>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Date</TableCell>
              <TableCell>Child</TableCell>
              <TableCell>Babysitter</TableCell>
              <TableCell>Type</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredIncidents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  {tabValue === 0 ? 'No open incidents' : 'No incidents found'}
                </TableCell>
              </TableRow>
            ) : (
              filteredIncidents.map((incident) => (
                <TableRow key={incident.id}>
                  <TableCell>{formatDate(incident.date)}</TableCell>
                  <TableCell>{getChildName(incident.childId)}</TableCell>
                  <TableCell>{getBabysitterName(incident.babysitterId)}</TableCell>
                  <TableCell>
                    <Chip 
                      label={incident.type.charAt(0).toUpperCase() + incident.type.slice(1)} 
                      color={getTypeColor(incident.type)} 
                      size="small" 
                    />
                  </TableCell>
                  <TableCell>
                    <Typography noWrap sx={{ maxWidth: 200 }}>
                      {incident.description}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={incident.status.replace('_', ' ').charAt(0).toUpperCase() + incident.status.replace('_', ' ').slice(1)} 
                      color={getStatusColor(incident.status)} 
                      size="small" 
                    />
                  </TableCell>
                  <TableCell>
                    <IconButton 
                      color="primary" 
                      onClick={() => handleOpenDialog(incident)}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton 
                      color="error" 
                      onClick={() => handleDelete(incident.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {selectedIncident ? 'Edit Incident' : 'Report New Incident'}
        </DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Date"
                  name="date"
                  type="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  required
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Time"
                  name="time"
                  type="time"
                  value={formData.time}
                  onChange={handleInputChange}
                  required
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Child</InputLabel>
                  <Select
                    name="childId"
                    value={formData.childId}
                    onChange={handleInputChange}
                    required
                  >
                    {children.map(child => (
                      <MenuItem key={child.id} value={child.id}>
                        {child.firstName} {child.lastName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Babysitter</InputLabel>
                  <Select
                    name="babysitterId"
                    value={formData.babysitterId}
                    onChange={handleInputChange}
                    required
                  >
                    {babysitters.map(babysitter => (
                      <MenuItem key={babysitter.id} value={babysitter.id}>
                        {babysitter.firstName} {babysitter.lastName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Type</InputLabel>
                  <Select
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    required
                  >
                    <MenuItem value="minor">Minor</MenuItem>
                    <MenuItem value="moderate">Moderate</MenuItem>
                    <MenuItem value="severe">Severe</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Status</InputLabel>
                  <Select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    required
                  >
                    <MenuItem value="open">Open</MenuItem>
                    <MenuItem value="in_progress">In Progress</MenuItem>
                    <MenuItem value="resolved">Resolved</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  multiline
                  rows={3}
                  required
                  placeholder="Describe the incident in detail"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Action Taken"
                  name="actionTaken"
                  value={formData.actionTaken}
                  onChange={handleInputChange}
                  multiline
                  rows={2}
                  placeholder="What actions were taken in response to the incident?"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Follow-up"
                  name="followUp"
                  value={formData.followUp}
                  onChange={handleInputChange}
                  multiline
                  rows={2}
                  placeholder="Any follow-up actions or recommendations"
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button type="submit" variant="contained" color="primary">
              {selectedIncident ? 'Update' : 'Submit'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};

export default IncidentManagement; 