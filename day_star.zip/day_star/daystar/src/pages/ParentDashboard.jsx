import React, { useState, useEffect } from 'react';
import {
  Grid,
  Typography,
  Card,
  CardContent,
  Box,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import {
  ChildCare as ChildIcon,
  EventNote as EventIcon,
  Report as ReportIcon,
  Payment as PaymentIcon
} from '@mui/icons-material';
import DashboardLayout from '../components/DashboardLayout';
import {
  getAllChildren,
  getChildAttendance,
  getAllIncidents,
  getAllPayments
} from '../services/api';
import { format } from 'date-fns';

const StatCard = ({ title, value, icon, color }) => (
  <Card sx={{ height: '100%' }}>
    <CardContent>
      <Grid container spacing={2} alignItems="center">
        <Grid item>
          <Box
            sx={{
              backgroundColor: `${color}20`,
              borderRadius: '50%',
              padding: 2,
              display: 'flex'
            }}
          >
            {icon}
          </Box>
        </Grid>
        <Grid item xs>
          <Typography variant="h6" component="div">
            {title}
          </Typography>
          <Typography variant="h4" component="div" sx={{ mt: 1 }}>
            {value}
          </Typography>
        </Grid>
      </Grid>
    </CardContent>
  </Card>
);

const ParentDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    children: 0,
    attendanceToday: 0,
    incidents: 0,
    pendingPayments: 0
  });
  const [childrenData, setChildrenData] = useState([]);
  const [selectedChild, setSelectedChild] = useState(null);
  const [attendanceData, setAttendanceData] = useState([]);
  const [showAttendanceDialog, setShowAttendanceDialog] = useState(false);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [
          childrenRes,
          attendanceRes,
          incidentsRes,
          paymentsRes
        ] = await Promise.all([
          getAllChildren(),
          getChildAttendance(),
          getAllIncidents(),
          getAllPayments()
        ]);

        const today = new Date().toISOString().split('T')[0];
        const todayAttendance = attendanceRes.data.filter(
          a => a.session_date === today
        );

        setStats({
          children: childrenRes.data.length,
          attendanceToday: todayAttendance.length,
          incidents: incidentsRes.data.length,
          pendingPayments: paymentsRes.data.filter(p => p.status === 'Pending').length
        });

        setChildrenData(childrenRes.data);
        setAttendanceData(attendanceRes.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const handleViewAttendance = (child) => {
    setSelectedChild(child);
    setShowAttendanceDialog(true);
  };

  if (loading) {
    return (
      <DashboardLayout>
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh'
          }}
        >
          <CircularProgress />
        </Box>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <Typography variant="h4" gutterBottom>
        Parent Dashboard
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="My Children"
            value={stats.children}
            icon={<ChildIcon sx={{ color: '#2e7d32' }} />}
            color="#2e7d32"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Today's Attendance"
            value={stats.attendanceToday}
            icon={<EventIcon sx={{ color: '#1976d2' }} />}
            color="#1976d2"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Incidents"
            value={stats.incidents}
            icon={<ReportIcon sx={{ color: '#d32f2f' }} />}
            color="#d32f2f"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Pending Payments"
            value={stats.pendingPayments}
            icon={<PaymentIcon sx={{ color: '#ed6c02' }} />}
            color="#ed6c02"
          />
        </Grid>

        {/* Children List */}
        <Grid item xs={12}>
          <Paper sx={{ p: 2, mt: 2 }}>
            <Typography variant="h6" gutterBottom>
              My Children
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Date of Birth</TableCell>
                    <TableCell>Session Type</TableCell>
                    <TableCell>Special Needs</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {childrenData.map((child) => (
                    <TableRow key={child.child_id}>
                      <TableCell>{child.full_name}</TableCell>
                      <TableCell>
                        {format(new Date(child.date_of_birth), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>{child.session_type}</TableCell>
                      <TableCell>{child.special_needs || 'None'}</TableCell>
                      <TableCell>
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={() => handleViewAttendance(child)}
                        >
                          View Attendance
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* Attendance Dialog */}
      <Dialog
        open={showAttendanceDialog}
        onClose={() => setShowAttendanceDialog(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Attendance History - {selectedChild?.full_name}
        </DialogTitle>
        <DialogContent>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Date</TableCell>
                  <TableCell>Session Type</TableCell>
                  <TableCell>Check In</TableCell>
                  <TableCell>Check Out</TableCell>
                  <TableCell>Babysitter</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {attendanceData
                  .filter(a => a.child_id === selectedChild?.child_id)
                  .map((attendance) => (
                    <TableRow key={attendance.attendance_id}>
                      <TableCell>
                        {format(new Date(attendance.session_date), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>{attendance.session_type}</TableCell>
                      <TableCell>
                        {attendance.check_in_time
                          ? format(new Date(attendance.check_in_time), 'HH:mm')
                          : 'Not checked in'}
                      </TableCell>
                      <TableCell>
                        {attendance.check_out_time
                          ? format(new Date(attendance.check_out_time), 'HH:mm')
                          : 'Not checked out'}
                      </TableCell>
                      <TableCell>
                        {`${attendance.Babysitter?.first_name} ${attendance.Babysitter?.last_name}`}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowAttendanceDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </DashboardLayout>
  );
};

export default ParentDashboard; 