import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Alert,
  CircularProgress,
} from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { getAllUsers } from '../services/api';

const validationSchema = yup.object({
  firstName: yup.string().required('First name is required'),
  lastName: yup.string().required('Last name is required'),
  dateOfBirth: yup.string().required('Date of birth is required'),
  gender: yup.string().required('Gender is required'),
  parentId: yup.string().required('Parent is required'),
  allergies: yup.string(),
  specialNeeds: yup.string(),
  emergencyContactName: yup.string().required('Emergency contact name is required'),
  emergencyContactPhone: yup
    .string()
    .required('Emergency contact phone is required')
    .matches(/^[0-9]{10}$/, 'Phone number must be 10 digits'),
});

const ChildRegistrationForm = ({ onSubmit, initialValues = null }) => {
  const [parents, setParents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchParents = async () => {
      try {
        setLoading(true);
        const users = await getAllUsers();
        const parentUsers = users.filter(user => user.role === 'Parent');
        setParents(parentUsers);
      } catch (err) {
        setError('Failed to fetch parents');
        console.error('Error fetching parents:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchParents();
  }, []);

  const formik = useFormik({
    initialValues: initialValues || {
      firstName: '',
      lastName: '',
      dateOfBirth: '',
      gender: '',
      parentId: '',
      allergies: '',
      specialNeeds: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);
        setError(null);
        await onSubmit(values);
      } catch (err) {
        setError(err.message || 'Failed to register child');
      } finally {
        setLoading(false);
      }
    },
  });

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Typography variant="h5" gutterBottom>
        {initialValues ? 'Edit Child Information' : 'Register New Child'}
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="firstName"
              name="firstName"
              label="First Name"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              error={formik.touched.firstName && Boolean(formik.errors.firstName)}
              helperText={formik.touched.firstName && formik.errors.firstName}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="lastName"
              name="lastName"
              label="Last Name"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              helperText={formik.touched.lastName && formik.errors.lastName}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="dateOfBirth"
              name="dateOfBirth"
              label="Date of Birth"
              type="date"
              value={formik.values.dateOfBirth}
              onChange={formik.handleChange}
              error={formik.touched.dateOfBirth && Boolean(formik.errors.dateOfBirth)}
              helperText={formik.touched.dateOfBirth && formik.errors.dateOfBirth}
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={formik.touched.gender && Boolean(formik.errors.gender)}>
              <InputLabel id="gender-label">Gender</InputLabel>
              <Select
                labelId="gender-label"
                id="gender"
                name="gender"
                value={formik.values.gender}
                label="Gender"
                onChange={formik.handleChange}
              >
                <MenuItem value="Male">Male</MenuItem>
                <MenuItem value="Female">Female</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
              <FormHelperText>
                {formik.touched.gender && formik.errors.gender}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth error={formik.touched.parentId && Boolean(formik.errors.parentId)}>
              <InputLabel id="parent-label">Parent</InputLabel>
              <Select
                labelId="parent-label"
                id="parentId"
                name="parentId"
                value={formik.values.parentId}
                label="Parent"
                onChange={formik.handleChange}
              >
                {parents.map((parent) => (
                  <MenuItem key={parent.id} value={parent.id}>
                    {parent.firstName} {parent.lastName}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText>
                {formik.touched.parentId && formik.errors.parentId}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="allergies"
              name="allergies"
              label="Allergies"
              multiline
              rows={2}
              value={formik.values.allergies}
              onChange={formik.handleChange}
              error={formik.touched.allergies && Boolean(formik.errors.allergies)}
              helperText={formik.touched.allergies && formik.errors.allergies}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              id="specialNeeds"
              name="specialNeeds"
              label="Special Needs"
              multiline
              rows={2}
              value={formik.values.specialNeeds}
              onChange={formik.handleChange}
              error={formik.touched.specialNeeds && Boolean(formik.errors.specialNeeds)}
              helperText={formik.touched.specialNeeds && formik.errors.specialNeeds}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="emergencyContactName"
              name="emergencyContactName"
              label="Emergency Contact Name"
              value={formik.values.emergencyContactName}
              onChange={formik.handleChange}
              error={formik.touched.emergencyContactName && Boolean(formik.errors.emergencyContactName)}
              helperText={formik.touched.emergencyContactName && formik.errors.emergencyContactName}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              id="emergencyContactPhone"
              name="emergencyContactPhone"
              label="Emergency Contact Phone"
              value={formik.values.emergencyContactPhone}
              onChange={formik.handleChange}
              error={formik.touched.emergencyContactPhone && Boolean(formik.errors.emergencyContactPhone)}
              helperText={formik.touched.emergencyContactPhone && formik.errors.emergencyContactPhone}
            />
          </Grid>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                disabled={loading}
                sx={{ minWidth: 120 }}
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : initialValues ? (
                  'Update'
                ) : (
                  'Register'
                )}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>
    </Paper>
  );
};

export default ChildRegistrationForm; 