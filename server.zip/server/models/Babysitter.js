const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Babysitter = sequelize.define('Babysitter', {
  babysitter_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true,
    references: {
      model: 'users',
      key: 'user_id'
    }
  },
  first_name: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  last_name: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  email: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  phone_number: {
    type: DataTypes.STRING(15),
    allowNull: false
  },
  nin: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true
  },
  date_of_birth: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  next_of_kin_name: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  next_of_kin_phone: {
    type: DataTypes.STRING(15),
    allowNull: false
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'babysitters'
});

Babysitter.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Babysitter; 