const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Babysitter = require('./Babysitter');
const Schedule = require('./Schedule');

const BabysitterAttendance = sequelize.define('BabysitterAttendance', {
  attendance_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  babysitter_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Babysitter,
      key: 'babysitter_id'
    }
  },
  schedule_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Schedule,
      key: 'schedule_id'
    }
  },
  check_in_time: {
    type: DataTypes.DATE,
    allowNull: true
  },
  check_out_time: {
    type: DataTypes.DATE,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('Present', 'Absent', 'Late'),
    allowNull: false,
    defaultValue: 'Absent'
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'Babysitter_Attendance'
});

BabysitterAttendance.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });
BabysitterAttendance.belongsTo(Schedule, { foreignKey: 'schedule_id' });

module.exports = BabysitterAttendance; 