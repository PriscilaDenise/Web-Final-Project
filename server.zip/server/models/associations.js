const User = require('./User');
const Babysitter = require('./Babysitter');
const Parent = require('./Parent');
const Child = require('./Child');
const Schedule = require('./Schedule');
const Attendance = require('./Attendance');
const Incident = require('./Incident');
const Payment = require('./Payment');
const Budget = require('./Budget');
const Notification = require('./Notification');

// User associations
User.hasOne(Babysitter, { foreignKey: 'user_id' });
Babysitter.belongsTo(User, { foreignKey: 'user_id' });

User.hasOne(Parent, { foreignKey: 'user_id' });
Parent.belongsTo(User, { foreignKey: 'user_id' });

// Babysitter associations
Babysitter.hasMany(Schedule, { foreignKey: 'babysitter_id' });
Schedule.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });

Babysitter.hasMany(Attendance, { foreignKey: 'babysitter_id' });
Attendance.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });

Babysitter.hasMany(Incident, { foreignKey: 'babysitter_id' });
Incident.belongsTo(Babysitter, { foreignKey: 'babysitter_id' });

// Child associations
Child.belongsTo(Parent, { foreignKey: 'parent_id', as: 'guardian' });
Parent.hasMany(Child, { foreignKey: 'parent_id' });

Child.hasMany(Attendance, { foreignKey: 'child_id' });
Attendance.belongsTo(Child, { foreignKey: 'child_id' });

Child.hasMany(Incident, { foreignKey: 'child_id' });
Incident.belongsTo(Child, { foreignKey: 'child_id' });

Child.hasMany(Payment, { foreignKey: 'child_id' });
Payment.belongsTo(Child, { foreignKey: 'child_id' });

// Payment associations
Payment.belongsTo(User, { foreignKey: 'parent_id', as: 'payer' });
User.hasMany(Payment, { foreignKey: 'parent_id' });

// Notification associations
Notification.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Notification, { foreignKey: 'user_id' });

module.exports = {
  User,
  Babysitter,
  Parent,
  Child,
  Schedule,
  Attendance,
  Incident,
  Payment,
  Budget,
  Notification
}; 