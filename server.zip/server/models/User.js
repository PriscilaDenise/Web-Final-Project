const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const bcrypt = require('bcryptjs');

const User = sequelize.define('User', {
  user_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true
  },
  password_hash: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  role: {
    type: DataTypes.ENUM('Manager', 'Parent', 'Babysitter'),
    allowNull: false
  }
}, {
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
  tableName: 'users'
});

// Instance method to validate password
User.prototype.validatePassword = async function(password) {
  try {
    console.log('Validating password for user:', this.username);
    console.log('Password hash:', this.password_hash);
    const result = await bcrypt.compare(password, this.password_hash);
    console.log('Password validation result:', result);
    return result;
  } catch (error) {
    console.error('Password validation error:', error);
    return false;
  }
};

// Class method to hash password
User.hashPassword = async function(password) {
  try {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
  } catch (error) {
    console.error('Password hashing error:', error);
    throw error;
  }
};

module.exports = User; 