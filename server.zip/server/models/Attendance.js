const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Babysitter = require('./Babysitter');

const Attendance = sequelize.define('Attendance', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  babysitterId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Babysitter,
      key: 'babysitter_id'
    }
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  checkIn: {
    type: DataTypes.TIME,
    allowNull: true
  },
  checkOut: {
    type: DataTypes.TIME,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('Present', 'Absent', 'Late', 'Early Leave'),
    allowNull: false,
    defaultValue: 'Present'
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  timestamps: true
});

Attendance.belongsTo(Babysitter, { foreignKey: 'babysitterId' });
Babysitter.hasMany(Attendance, { foreignKey: 'babysitterId' });

module.exports = Attendance; 