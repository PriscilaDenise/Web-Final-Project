const express = require('express');
const router = express.Router();
const { Incident, Child, Babysitter, User } = require('../models');
const { authenticateToken } = require('../middleware/auth');

// Middleware to check if user is manager
const isManager = (req, res, next) => {
  if (req.user.role !== 'Manager') {
    return res.status(403).json({ message: 'Access denied. Manager only.' });
  }
  next();
};

// Report new incident
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      child_id,
      babysitter_id,
      incident_date,
      description,
      severity
    } = req.body;

    // If user is babysitter, ensure they can only report incidents for themselves
    if (req.user.role === 'Babysitter' && req.user.babysitter.id !== babysitter_id) {
      return res.status(403).json({ message: 'Babysitters can only report their own incidents' });
    }

    const incident = await Incident.create({
      child_id,
      babysitter_id,
      incident_date,
      description,
      severity,
      status: 'pending'
    });

    res.status(201).json({
      message: 'Incident reported successfully',
      incident
    });
  } catch (error) {
    res.status(500).json({ message: 'Error reporting incident', error: error.message });
  }
});

// Get all incidents
router.get('/', authenticateToken, async (req, res) => {
  try {
    const incidents = await Incident.findAll({
      include: [
        {
          model: Child,
          attributes: ['id', 'first_name', 'last_name']
        },
        {
          model: Babysitter,
          attributes: ['id', 'first_name', 'last_name']
        }
      ]
    });
    res.json(incidents);
  } catch (error) {
    console.error('Error fetching incidents:', error);
    res.status(500).json({ message: 'Error fetching incidents' });
  }
});

// Get incident by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const incident = await Incident.findByPk(req.params.id, {
      include: [
        {
          model: Child,
          attributes: ['id', 'first_name', 'last_name']
        },
        {
          model: Babysitter,
          attributes: ['id', 'first_name', 'last_name']
        }
      ]
    });
    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }
    res.json(incident);
  } catch (error) {
    console.error('Error fetching incident:', error);
    res.status(500).json({ message: 'Error fetching incident' });
  }
});

// Update incident status (Manager only)
router.put('/:id/status', authenticateToken, isManager, async (req, res) => {
  try {
    const { status } = req.body;
    const incident = await Incident.findByPk(req.params.id);

    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }

    incident.status = status;
    await incident.save();

    res.json({ message: 'Incident status updated successfully', incident });
  } catch (error) {
    console.error('Error updating incident status:', error);
    res.status(500).json({ message: 'Error updating incident status' });
  }
});

// Update incident (Manager or Babysitter who created it)
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const incident = await Incident.findByPk(req.params.id);

    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }

    // Check if user is authorized to update
    if (req.user.role === 'Babysitter' && incident.babysitter_id !== req.user.babysitter.id) {
      return res.status(403).json({ message: 'You can only update your own incidents' });
    }

    const { description, severity, status } = req.body;
    
    if (description) incident.description = description;
    if (severity) incident.severity = severity;
    if (status && req.user.role === 'Manager') incident.status = status;

    await incident.save();

    res.json({ message: 'Incident updated successfully', incident });
  } catch (error) {
    console.error('Error updating incident:', error);
    res.status(500).json({ message: 'Error updating incident' });
  }
});

// Delete incident (Manager only)
router.delete('/:id', authenticateToken, isManager, async (req, res) => {
  try {
    const incident = await Incident.findByPk(req.params.id);

    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }

    await incident.destroy();
    res.json({ message: 'Incident deleted successfully' });
  } catch (error) {
    console.error('Error deleting incident:', error);
    res.status(500).json({ message: 'Error deleting incident' });
  }
});

module.exports = router; 