const express = require('express');
const router = express.Router();
const { Incident, Child, Babysitter } = require('../models');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

// Get all incidents (Manager and Babysitter)
router.get('/', authenticateToken, authorizeRole(['manager', 'babysitter']), async (req, res) => {
  try {
    const incidents = await Incident.findAll({
      include: [
        { model: Child, attributes: ['id', 'first_name', 'last_name'] },
        { model: Babysitter, attributes: ['id', 'first_name', 'last_name'] }
      ],
      order: [['incident_date', 'DESC']]
    });
    res.json(incidents);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get incidents for a specific child (Parent)
router.get('/child/:childId', authenticateToken, authorizeRole(['parent']), async (req, res) => {
  try {
    const incidents = await Incident.findAll({
      where: { child_id: req.params.childId },
      include: [
        { model: Child, attributes: ['id', 'first_name', 'last_name'] },
        { model: Babysitter, attributes: ['id', 'first_name', 'last_name'] }
      ],
      order: [['incident_date', 'DESC']]
    });
    res.json(incidents);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create new incident (Babysitter)
router.post('/', authenticateToken, authorizeRole(['babysitter']), async (req, res) => {
  try {
    const incident = await Incident.create({
      ...req.body,
      babysitter_id: req.user.babysitter.id
    });
    res.status(201).json(incident);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update incident (Manager and Babysitter)
router.put('/:id', authenticateToken, authorizeRole(['manager', 'babysitter']), async (req, res) => {
  try {
    const incident = await Incident.findByPk(req.params.id);
    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }

    // Only allow babysitters to update their own incidents
    if (req.user.role === 'babysitter' && incident.babysitter_id !== req.user.babysitter.id) {
      return res.status(403).json({ message: 'Not authorized to update this incident' });
    }

    await incident.update(req.body);
    res.json(incident);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete incident (Manager only)
router.delete('/:id', authenticateToken, authorizeRole(['manager']), async (req, res) => {
  try {
    const incident = await Incident.findByPk(req.params.id);
    if (!incident) {
      return res.status(404).json({ message: 'Incident not found' });
    }

    await incident.destroy();
    res.json({ message: 'Incident deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router; 