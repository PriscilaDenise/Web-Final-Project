const express = require('express');
const router = express.Router();
const { Child, User } = require('../models');
const { authenticateToken } = require('../middleware/auth');

// Get all children
router.get('/', authenticateToken, async (req, res) => {
  try {
    const children = await Child.findAll({
      include: [{
        model: User,
        attributes: ['full_name', 'email']
      }]
    });
    res.json(children);
  } catch (error) {
    console.error('Error fetching children:', error);
    res.status(500).json({ message: 'Error fetching children' });
  }
});

// Get child by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const child = await Child.findByPk(req.params.id, {
      include: [{
        model: User,
        attributes: ['full_name', 'email']
      }]
    });
    if (!child) {
      return res.status(404).json({ message: 'Child not found' });
    }
    res.json(child);
  } catch (error) {
    console.error('Error fetching child:', error);
    res.status(500).json({ message: 'Error fetching child' });
  }
});

// Create new child
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { user_id, date_of_birth, allergies, special_needs } = req.body;
    
    // Check if parent exists
    const parent = await User.findByPk(user_id);
    if (!parent) {
      return res.status(404).json({ message: 'Parent not found' });
    }

    const child = await Child.create({
      user_id,
      date_of_birth,
      allergies,
      special_needs
    });

    res.status(201).json(child);
  } catch (error) {
    console.error('Error creating child:', error);
    res.status(500).json({ message: 'Error creating child' });
  }
});

// Update child
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { date_of_birth, allergies, special_needs } = req.body;
    const child = await Child.findByPk(req.params.id);
    
    if (!child) {
      return res.status(404).json({ message: 'Child not found' });
    }

    await child.update({
      date_of_birth,
      allergies,
      special_needs
    });

    res.json(child);
  } catch (error) {
    console.error('Error updating child:', error);
    res.status(500).json({ message: 'Error updating child' });
  }
});

// Delete child
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const child = await Child.findByPk(req.params.id);
    
    if (!child) {
      return res.status(404).json({ message: 'Child not found' });
    }

    await child.destroy();
    res.json({ message: 'Child deleted successfully' });
  } catch (error) {
    console.error('Error deleting child:', error);
    res.status(500).json({ message: 'Error deleting child' });
  }
});

module.exports = router; 