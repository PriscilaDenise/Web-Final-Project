const { User } = require('../models');
const bcrypt = require('bcryptjs');

async function createTestUser() {
  try {
    // Check if test user already exists
    const existingUser = await User.findOne({ where: { username: 'admin' } });
    if (existingUser) {
      console.log('Test user already exists');
      return;
    }

    // Create a test user
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('admin123', salt);

    const user = await User.create({
      username: 'admin',
      password_hash: hashedPassword,
      role: 'Manager'
    });

    console.log('Test user created successfully:', user.username);
  } catch (error) {
    console.error('Error creating test user:', error);
  }
}

// Run the function
createTestUser(); 