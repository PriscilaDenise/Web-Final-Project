const { User } = require('../models');
const bcrypt = require('bcryptjs');

async function updateUserPassword() {
  try {
    // Find the user
    const user = await User.findOne({ where: { username: 'oscar' } });
    if (!user) {
      console.log('User "oscar" not found');
      return;
    }

    // Hash the new password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('oscar123', salt);

    // Update the password
    await user.update({ password_hash: hashedPassword });
    console.log('Password updated successfully for user:', user.username);
  } catch (error) {
    console.error('Error updating password:', error);
  }
}

// Run the function
updateUserPassword(); 